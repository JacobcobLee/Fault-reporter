"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var format_docker_advice_1 = require("./format-docker-advice");
Object.defineProperty(exports, "dockerRemediationForDisplay", { enumerable: true, get: function () { return format_docker_advice_1.dockerRemediationForDisplay; } });
var format_docker_binary_issues_1 = require("./format-docker-binary-issues");
Object.defineProperty(exports, "formatDockerBinariesIssues", { enumerable: true, get: function () { return format_docker_binary_issues_1.formatDockerBinariesIssues; } });
var format_docker_binary_heading_1 = require("./format-docker-binary-heading");
Object.defineProperty(exports, "createDockerBinaryHeading", { enumerable: true, get: function () { return format_docker_binary_heading_1.createDockerBinaryHeading; } });
//# sourceMappingURL=index.js.map