"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.args = void 0;
const abbrev = require("abbrev");
const debugModule = require("debug");
const modes_1 = require("./modes");
const types_1 = require("../lib/types");
const container_1 = require("../lib/container");
const alias = abbrev('copy', 'version', 'debug', 'help', 'quiet', 'interactive', 'dev');
alias.d = 'debug'; // always make `-d` debug
alias.t = 'test';
// The -d flag enables printing the messages for predefined namespaces.
// Additional ones can be specified (comma-separated) in the DEBUG environment variable.
const DEBUG_DEFAULT_NAMESPACES = [
    'snyk-test',
    'snyk',
    'snyk-gradle-plugin',
    'snyk-sbt-plugin',
    'snyk-mvn-plugin',
    'snyk-java-call-graph-builder',
];
// NOTE[muscar] This is accepted in seconds for UX reasons, the mavem plugin
// turns it into milliseconds before calling the call graph generator
const REACHABLE_VULNS_TIMEOUT = 5 * 60; // 5 min (in seconds)
function dashToCamelCase(dash) {
    return dash.indexOf('-') < 0
        ? dash
        : dash.replace(/-[a-z]/g, (m) => m[1].toUpperCase());
}
function args(rawArgv) {
    const argv = {
        _: [],
    };
    for (let arg of rawArgv.slice(2)) {
        if (argv._doubleDashArgs) {
            argv._doubleDashArgs.push(arg);
        }
        else if (arg === '--') {
            argv._doubleDashArgs = [];
        }
        else if (arg[0] === '-') {
            arg = arg.slice(1);
            if (alias[arg] !== undefined) {
                argv[alias[arg]] = true;
            }
            else if (arg[0] === '-') {
                arg = arg.slice(1);
                if (arg.indexOf('=') === -1) {
                    argv[arg] = true;
                }
                else {
                    const parts = arg.split('=');
                    argv[parts.shift()] = parts.join('=');
                }
            }
            else {
                argv[arg] = true;
            }
        }
        else {
            argv._.push(arg);
        }
    }
    // By passing `-d` to the CLI, we enable the debugging output.
    // It needs to happen BEFORE any of the `debug(namespace)` calls needed to create loggers.
    // Therefore, the code used by the CLI should create the loggers in a lazy fashion
    // or be `require`d after this code.
    // TODO(BST-648): sort this out reliably
    if (argv.debug) {
        let enable = DEBUG_DEFAULT_NAMESPACES.join(',');
        if (process.env.DEBUG) {
            enable += ',' + process.env.DEBUG;
        }
        // Storing in the global state, because just "debugModule.enable" call won't affect different instances of `debug`
        // module imported by plugins, libraries etc.
        process.env.DEBUG = enable;
        debugModule.enable(enable);
    }
    const debug = debugModule('snyk');
    // Late require, see the note re "debug" option above.
    const cli = require('./commands');
    // the first argument is the command we'll execute, everything else will be
    // an argument to our command, like `snyk help protect`
    let command = argv._.shift(); // can actually be undefined
    // snyk [mode?] [command] [paths?] [options-double-dash]
    command = modes_1.displayModeHelp(command, argv);
    command = modes_1.parseMode(command, argv);
    // alias switcheroo - allows us to have
    if (cli.aliases[command]) {
        command = cli.aliases[command];
    }
    // alias `-v` to `snyk version`
    if (argv.version) {
        command = 'version';
    }
    if (!command || argv.help || command === 'help') {
        // bit of a song and dance to support `snyk -h` and `snyk help`
        if (argv.help === true || command === 'help') {
            argv.help = 'help';
        }
        command = 'help';
        if (!argv._.length) {
            argv._.unshift(argv.help || 'help');
        }
    }
    if (command && command.indexOf('config:') === 0) {
        // config looks like `config:set x=y` or `config:get x`
        // so we need to mangle the commands into this format:
        // snyk.config('set', 'api=x')
        // snyk.config('get', 'api') // etc
        const tmp = command.split(':');
        command = tmp.shift();
        argv._.unshift(tmp.shift());
    }
    let method = cli[command];
    if (!method) {
        // if we failed to find a command, then default to an error
        method = require('../lib/errors/legacy-errors');
        argv._.push(command);
    }
    // TODO: Once experimental flag became default this block should be
    // moved to inside the parseModes function for container mode
    const imageSavePath = container_1.getContainerImageSavePath();
    if (imageSavePath) {
        argv['imageSavePath'] = imageSavePath;
    }
    if (command in types_1.SupportedCliCommands) {
        // copy all the options across to argv._ as an object
        argv._.push(argv);
    }
    // TODO: eventually all arguments should be transformed like this.
    const argumentsToTransform = [
        'package-manager',
        'packages-folder',
        'severity-threshold',
        'strict-out-of-sync',
        'all-sub-projects',
        'sub-project',
        'gradle-sub-project',
        'skip-unresolved',
        'scan-all-unmanaged',
        'fail-on',
        'all-projects',
        'yarn-workspaces',
        'detection-depth',
        'reachable',
        'reachable-vulns',
        'reachable-timeout',
        'reachable-vulns-timeout',
        'integration-name',
        'integration-version',
    ];
    for (const dashedArg of argumentsToTransform) {
        if (argv[dashedArg]) {
            const camelCased = dashToCamelCase(dashedArg);
            if (camelCased === dashedArg) {
                continue;
            }
            argv[camelCased] = argv[dashedArg];
            delete argv[dashedArg];
        }
    }
    if (argv.skipUnresolved !== undefined) {
        if (argv.skipUnresolved === 'false') {
            argv.allowMissing = false;
        }
        else {
            argv.allowMissing = true;
        }
    }
    if (argv.strictOutOfSync !== undefined) {
        if (argv.strictOutOfSync === 'false') {
            argv.strictOutOfSync = false;
        }
        else {
            argv.strictOutOfSync = true;
        }
    }
    if (argv.reachableTimeout === undefined &&
        argv.reachableVulnsTimeout === undefined) {
        argv.reachableVulnsTimeout = REACHABLE_VULNS_TIMEOUT.toString();
    }
    // Alias
    const aliases = {
        gradleSubProject: 'subProject',
        container: 'docker',
        reachable: 'reachableVulns',
        reachableTimeout: 'callGraphBuilderTimeout',
        reachableVulnsTimeout: 'callGraphBuilderTimeout',
    };
    for (const argAlias in aliases) {
        if (argv[argAlias]) {
            const target = aliases[argAlias];
            argv[target] = argv[argAlias];
            delete argv[argAlias];
        }
    }
    if (argv.insecure) {
        global.ignoreUnknownCA = true;
    }
    debug(command, argv);
    return {
        command,
        method,
        options: argv,
    };
}
exports.args = args;
//# sourceMappingURL=args.js.map